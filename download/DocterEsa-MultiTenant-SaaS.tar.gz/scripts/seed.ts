import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

async function main() {
  console.log('Seeding database...\n')

  // 1. Create Super Admin
  const sa = await db.superAdmin.upsert({
    where: { email: 'super@docteresa.com' },
    update: {},
    create: {
      email: 'super@docteresa.com',
      password: 'super123',
      name: 'Super Admin',
    },
  })
  console.log('Super Admin created: ' + sa.email + ' / super123')

  // 2. Create sample clinic "Falaha Clinic"
  const clinic = await db.clinic.upsert({
    where: { slug: 'falaha' },
    update: {},
    create: {
      name: 'Falaha Clinic',
      slug: 'falaha',
      city: 'Mumbai',
      plan: 'standard',
      phone: '+91-9876543210',
      email: 'info@falaha.com',
      address: '123 Health Street, Andheri West',
      primaryColor: '#0A76D8',
      maxDoctors: 5,
      maxPatients: 500,
      createdAt: new Date().toISOString(),
      admins: {
        create: {
          email: 'admin@falaha.com',
          password: 'admin123',
          name: 'Falaha Admin',
          phone: '+91-9876543210',
        },
      },
      specialties: {
        create: [
          { name: 'General Medicine' },
          { name: 'Dental' },
          { name: 'Cardiology' },
          { name: 'Orthopedic' },
          { name: 'ENT' },
          { name: 'Pediatrics' },
        ],
      },
    },
  })
  console.log('Clinic created: ' + clinic.name + ' (slug: ' + clinic.slug + ')')
  console.log('   Admin: admin@falaha.com / admin123')

  // 3. Create a sample doctor for Falaha
  const doc = await db.doctor.create({
    data: {
      clinicid: clinic.clinicid,
      docemail: 'dr@falaha.com',
      docname: 'Dr. Arif Khan',
      docpassword: 'doc123',
      docnic: 'NIC12345',
      doctel: '+91-9988776655',
      specialties: 1,
    },
  })
  console.log('Doctor created: ' + doc.docname + ' (dr@falaha.com / doc123)')

  // 4. Create a sample patient for Falaha
  const pat = await db.patient.create({
    data: {
      clinicid: clinic.clinicid,
      pemail: 'patient@falaha.com',
      pname: 'Rahul Sharma',
      ppassword: 'pat123',
      paddress: '456 Park Road, Mumbai',
      pnic: 'NIC-PAT-001',
      pdob: '1990-05-15',
      ptel: '+91-8877665544',
    },
  })
  console.log('Patient created: ' + pat.pname + ' (patient@falaha.com / pat123)')

  // 5. Create second clinic "City Hospital"
  const clinic2 = await db.clinic.upsert({
    where: { slug: 'cityhospital' },
    update: {},
    create: {
      name: 'City Hospital',
      slug: 'cityhospital',
      city: 'Delhi',
      plan: 'free',
      phone: '+91-1122334455',
      email: 'info@cityhospital.com',
      address: '789 Main Road, Connaught Place',
      primaryColor: '#E74C3C',
      maxDoctors: 1,
      maxPatients: 50,
      createdAt: new Date().toISOString(),
      admins: {
        create: {
          email: 'admin@cityhospital.com',
          password: 'admin123',
          name: 'City Admin',
          phone: '+91-1122334455',
        },
      },
      specialties: {
        create: [
          { name: 'General Medicine' },
          { name: 'Dental' },
          { name: 'Cardiology' },
          { name: 'Orthopedic' },
        ],
      },
    },
  })
  console.log('Clinic created: ' + clinic2.name + ' (slug: ' + clinic2.slug + ')')
  console.log('   Admin: admin@cityhospital.com / admin123')

  console.log('\nSeeding complete!')
  console.log('\nLogin Credentials:')
  console.log('   Super Admin: super@docteresa.com / super123')
  console.log('   Falaha Admin: admin@falaha.com / admin123')
  console.log('   Falaha Doctor: dr@falaha.com / doc123')
  console.log('   Falaha Patient: patient@falaha.com / pat123')
  console.log('   City Hospital Admin: admin@cityhospital.com / admin123')
  console.log('\nAccess Clinics:')
  console.log('   Main: http://localhost:3000')
  console.log('   Falaha: http://localhost:3000?clinic=falaha')
  console.log('   City Hospital: http://localhost:3000?clinic=cityhospital')
}

main()
  .catch(console.error)
  .finally(() => db.$disconnect())
